# Reasoning Task Framework

A reusable framework for building LLM-powered reasoning tasks against the Portkey gateway. Add a new use case by writing four files (input schema, output schema, prompt, task config) — the framework handles orchestration, guardrails, validation, observability, retries, and audit logging.

## Design principle

**Task authors write schemas, prompts, and config. Framework owners write everything else.** Never let task-specific logic leak into `/framework/`, and never let framework concerns leak into `/tasks/`.

## Layout

```
framework/                  Shared infrastructure (written once)
  runner.py                 Orchestrator — the only entry point
  portkey_client.py         Thin Portkey wrapper
  schema_validator.py       JSON Schema validation
  guardrails/               Built-in guardrail library
    __init__.py
    base.py
    schema_validation.py
    json_only.py
    word_count.py
    prohibited_phrases.py
    required_phrases.py
    numeric_match.py
    referenced_ids.py
    pii_redaction.py
  metadata.py               Tag extraction from input
  exceptions.py
  config.py                 Loads task.yaml
  cache.py                  Sub-task caching
  logging_setup.py
  types.py                  Shared types

tasks/                      One folder per use case
  precall_brief/
    task.yaml
    input_schema.json
    output_schema.json
    prompt.md
    tests/fixtures/
  fnol_brief/
    task.yaml
    input_schema.json
    output_schema.json
    prompt.md
    tests/fixtures/

portkey_config/             Synced to Portkey via scripts/sync_portkey.py
  configs/
  prompts/

scripts/
  sync_portkey.py           Push prompts/configs to Portkey
  run_task.py               CLI for executing a task
  run_fixtures.py           Regression test runner

tests/                      Framework unit tests
```

## Adding a new task

1. `mkdir tasks/<task_id>`
2. Write `input_schema.json`, `output_schema.json`, `prompt.md`, `task.yaml`
3. Add fixtures in `tests/fixtures/`
4. `python scripts/run_fixtures.py <task_id>` to validate
5. PR for review
6. CI syncs prompt to Portkey on merge

## Quickstart

```bash
pip install -r requirements.txt
export PORTKEY_API_KEY=...
export PORTKEY_VIRTUAL_KEY_ANTHROPIC=...
python scripts/run_task.py precall_brief tasks/precall_brief/tests/fixtures/loyal_customer.json
```
