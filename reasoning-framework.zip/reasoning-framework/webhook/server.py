"""Portkey webhook guardrail service.

Architecture:
    Portkey gateway receives a request and calls the configured webhook URL
    with the model's output. This service runs the deterministic checks
    (numeric_values_match_input, referenced_ids_exist, prohibited_phrases,
    required_phrases_present) and returns a verdict.

    Why server-side: every Portkey call gets checked, not just calls through
    the framework runner. Other teams, ad-hoc scripts, direct API integrations
    are all covered. The webhook is the chokepoint.

    Why reuse framework guardrails: identical checks in-process and at the
    gateway, guaranteed. No drift.

Portkey webhook contract (verify against current Portkey docs):
    POST <webhook_url>
    Headers:
        x-portkey-trace-id: <id>
        x-task-id: <task_id>           # propagated from request metadata
        x-task-version: <version>
        x-mode: enforce | log_only     # for shadow rollout
    Body:
        {
          "request": {...},            # original request, including variables
          "response": {...},           # model output (OpenAI-shape)
          "metadata": {...}            # request metadata
        }
    Response 200:
        {"verdict": true|false, "reasons": [...], "checks": [...]}

Deployment: run behind TLS, allowlist Portkey's egress IPs, add signature
verification using a shared secret (PORTKEY_WEBHOOK_SECRET) — see verify_signature().
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel

# Reuse the framework — that's the whole point.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from framework.config import GuardrailSpec, TaskConfig, load_task_config  # noqa: E402
from framework.guardrails import build_guardrail  # noqa: E402
from framework.logging_setup import configure_logging, get_logger  # noqa: E402
from framework.types import GuardrailStage  # noqa: E402

configure_logging(level=os.getenv("LOG_LEVEL", "INFO"))
log = get_logger(__name__)

app = FastAPI(title="Portkey Guardrail Webhook", version="1.0.0")

TASKS_ROOT = Path(os.getenv("TASKS_ROOT", "tasks"))
WEBHOOK_SECRET = os.getenv("PORTKEY_WEBHOOK_SECRET", "")
# Which guardrail names are appropriate to run at the gateway. Some checks
# (like pii_redaction) only make sense in-process before the call.
GATEWAY_GUARDRAILS = {
    "numeric_values_match_input",
    "referenced_ids_exist",
    "prohibited_phrases",
    "required_phrases_present",
    "word_count",
}


# In-memory task config cache. Refreshed on demand; tasks rarely change in prod
# and the cost of reloading on every request is non-trivial under load.
_task_cache: dict[str, tuple[TaskConfig, float]] = {}
_CACHE_TTL_SECONDS = 60


def _load_task(task_id: str) -> TaskConfig:
    now = time.time()
    cached = _task_cache.get(task_id)
    if cached and now - cached[1] < _CACHE_TTL_SECONDS:
        return cached[0]
    cfg = load_task_config(TASKS_ROOT / task_id)
    _task_cache[task_id] = (cfg, now)
    return cfg


def _verify_signature(raw_body: bytes, provided_sig: str | None) -> None:
    """Reject forged webhook calls. Portkey signs payloads with a shared secret.

    Skip verification if no secret configured (dev mode); fail closed otherwise.
    """
    if not WEBHOOK_SECRET:
        return
    if not provided_sig:
        raise HTTPException(status_code=401, detail="missing signature")
    expected = hmac.new(
        WEBHOOK_SECRET.encode(), raw_body, hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(expected, provided_sig):
        raise HTTPException(status_code=401, detail="signature mismatch")


def _extract_model_output(response_body: dict[str, Any]) -> Any:
    """Pull the model's text output from the OpenAI-compatible response shape."""
    choices = response_body.get("choices") or []
    if not choices:
        return ""
    msg = choices[0].get("message", {})
    content = msg.get("content")
    if isinstance(content, list):
        return "".join(b.get("text", "") for b in content if isinstance(b, dict))
    return content or ""


def _parse_json_or_raw(text: str) -> Any:
    """Try to parse JSON; fall back to raw text. Guardrails handle both."""
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return text


# ----- API -----


class CheckResult(BaseModel):
    name: str
    passed: bool
    detail: str = ""


class WebhookResponse(BaseModel):
    verdict: bool
    reasons: list[str] = []
    checks: list[CheckResult] = []
    mode: str = "enforce"
    task_id: str | None = None
    task_version: int | None = None


@app.get("/healthz")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/readyz")
def ready() -> dict[str, Any]:
    """Validate that at least one task config loads — catches misconfigured pods."""
    tasks = [p.name for p in TASKS_ROOT.iterdir() if p.is_dir()]
    return {"status": "ok", "tasks_available": tasks}


@app.post("/guardrails/check", response_model=WebhookResponse)
async def check(
    request: Request,
    x_task_id: str = Header(...),
    x_task_version: str | None = Header(default=None),
    x_mode: str = Header(default="enforce"),
    x_portkey_trace_id: str | None = Header(default=None),
    x_portkey_signature: str | None = Header(default=None),
) -> WebhookResponse:
    raw = await request.body()
    _verify_signature(raw, x_portkey_signature)

    try:
        body = json.loads(raw)
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="invalid JSON body")

    log.info(
        "webhook_received",
        task_id=x_task_id,
        task_version=x_task_version,
        portkey_trace_id=x_portkey_trace_id,
        mode=x_mode,
    )

    try:
        task_cfg = _load_task(x_task_id)
    except Exception as e:
        log.error("task_load_failed", task_id=x_task_id, error=str(e))
        # Fail closed in enforce mode, open in log_only.
        if x_mode == "log_only":
            return WebhookResponse(
                verdict=True, reasons=[f"task_load_failed: {e}"], mode=x_mode,
                task_id=x_task_id,
            )
        raise HTTPException(status_code=404, detail=f"unknown task: {x_task_id}")

    # Pull the original input out of the request variables. The runner sends
    # it under variables.input_json; if that's not how this call was routed,
    # bail out cleanly rather than guess.
    request_body = body.get("request") or {}
    variables = request_body.get("variables") or {}
    input_payload = variables.get("input_json")
    if input_payload is None:
        # Some Portkey routings put it at top level or under "input".
        input_payload = body.get("input") or variables.get("input")
    if not isinstance(input_payload, dict):
        log.warning("no_input_payload_for_cross_checks", task_id=x_task_id)
        input_payload = {}

    response_body = body.get("response") or {}
    raw_text = _extract_model_output(response_body)
    output_payload = _parse_json_or_raw(raw_text)

    # Run only the guardrails appropriate for gateway-side enforcement.
    results: list[CheckResult] = []
    reasons: list[str] = []
    for spec in task_cfg.output_guardrails:
        if spec.name not in GATEWAY_GUARDRAILS:
            continue
        # schema_validation needs the schema injected (the runner does this
        # too); replicate that step here.
        params = dict(spec.params)
        if spec.name == "schema_validation":
            params["_schema"] = task_cfg.output_schema
        try:
            guardrail = build_guardrail(spec.name, params)
            result = guardrail.check(
                output_payload, stage=GuardrailStage.OUTPUT,
                input_payload=input_payload,
            )
        except Exception as e:
            log.exception("guardrail_exception", guardrail=spec.name)
            # Don't let a guardrail bug bring down the gateway. Log and fail
            # closed in enforce mode.
            results.append(CheckResult(
                name=spec.name, passed=False,
                detail=f"guardrail raised {type(e).__name__}",
            ))
            reasons.append(f"{spec.name}: exception")
            continue

        results.append(CheckResult(
            name=result.name, passed=result.passed, detail=result.detail,
        ))
        if not result.passed:
            reasons.append(f"{result.name}: {result.detail}")

    enforced_verdict = len(reasons) == 0
    verdict = True if x_mode == "log_only" else enforced_verdict

    log.info(
        "webhook_decision",
        task_id=x_task_id,
        verdict=verdict,
        enforced_verdict=enforced_verdict,
        mode=x_mode,
        reason_count=len(reasons),
        portkey_trace_id=x_portkey_trace_id,
    )

    return WebhookResponse(
        verdict=verdict,
        reasons=reasons,
        checks=results,
        mode=x_mode,
        task_id=x_task_id,
        task_version=int(x_task_version) if x_task_version else None,
    )
