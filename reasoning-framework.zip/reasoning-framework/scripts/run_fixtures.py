"""Run every fixture for a task and report results.

Usage:
    python scripts/run_fixtures.py <task_id> [--mock]

Used in CI to catch:
    - Prompt changes that break the output schema
    - Guardrail changes that newly reject previously-passing fixtures
    - Sub-task injection failures
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import click

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from framework.logging_setup import configure_logging  # noqa: E402
from framework.portkey_client import PortkeyClient  # noqa: E402
from framework.runner import ReasoningTaskRunner  # noqa: E402
from framework.types import TaskStatus  # noqa: E402

# Reuse the mock factories from run_task
from scripts.run_task import _build_mock_factory  # noqa: E402


@click.command()
@click.argument("task_id")
@click.option("--mock", is_flag=True, default=True, help="Use mock Portkey (default in CI).")
@click.option("--tasks-root", default="tasks")
def main(task_id: str, mock: bool, tasks_root: str) -> None:
    configure_logging(level="WARNING")
    fixtures_dir = Path(tasks_root) / task_id / "tests" / "fixtures"
    if not fixtures_dir.exists():
        print(f"No fixtures directory: {fixtures_dir}")
        sys.exit(1)

    fixtures = sorted(fixtures_dir.glob("*.json"))
    if not fixtures:
        print(f"No fixtures found in {fixtures_dir}")
        sys.exit(1)

    client = (
        PortkeyClient(mock=True, mock_response_factory=_build_mock_factory(task_id))
        if mock
        else PortkeyClient()
    )
    runner = ReasoningTaskRunner(task_id=task_id, tasks_root=tasks_root, portkey_client=client)

    passes = 0
    fails = 0
    for fixture in fixtures:
        with fixture.open() as f:
            input_data = json.load(f)
        result = runner.execute(input_data)
        if result.status == TaskStatus.SUCCESS:
            print(f"PASS  {fixture.name}")
            passes += 1
        else:
            print(f"FAIL  {fixture.name}  [{result.status.value}]")
            for r in result.rejection_reasons:
                print(f"        - {r}")
            if result.error:
                print(f"        error: {result.error}")
            fails += 1

    print(f"\n{passes} passed, {fails} failed of {len(fixtures)}")
    sys.exit(0 if fails == 0 else 1)


if __name__ == "__main__":
    main()
