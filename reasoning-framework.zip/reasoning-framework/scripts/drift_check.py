"""Detect drift between sources of truth.

Three drift modes to watch:

1. Repo prompt.md  vs  Portkey-stored prompt.
       If someone edits a prompt in the Portkey UI for a "quick fix", the repo
       no longer matches what's running. This is the most common audit failure.

2. Repo task.yaml guardrails  vs  Portkey-stored guardrail config.
       Guardrails configured at the gateway must reference the same checks
       configured in the repo.

3. Framework guardrail logic  vs  Webhook guardrail logic.
       Should never drift because they import the same module — but verify by
       running the same input through both and comparing verdicts.

Run nightly. Page on diff.

Usage:
    python scripts/drift_check.py [--mode repo_vs_portkey|framework_vs_webhook|all]
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import click
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from framework.guardrails import build_guardrail  # noqa: E402
from framework.types import GuardrailStage  # noqa: E402


def _check_repo_vs_portkey(tasks_root: Path) -> list[str]:
    """Compare each repo prompt.md to its Portkey-stored counterpart."""
    api_key = os.getenv("PORTKEY_API_KEY")
    if not api_key:
        return ["PORTKEY_API_KEY not set — skipped repo_vs_portkey"]

    try:
        from portkey_ai import Portkey  # type: ignore
    except ImportError:
        return ["portkey-ai not installed — skipped repo_vs_portkey"]

    client = Portkey(api_key=api_key)
    diffs: list[str] = []
    for task_dir in tasks_root.iterdir():
        if not task_dir.is_dir():
            continue
        task_yaml = task_dir / "task.yaml"
        prompt_md = task_dir / "prompt.md"
        if not (task_yaml.exists() and prompt_md.exists()):
            continue
        cfg = yaml.safe_load(task_yaml.read_text())
        prompt_id = cfg["prompt"]["portkey_prompt_id"]
        repo_text = prompt_md.read_text()
        try:
            # Exact API surface varies by SDK version; this is the conceptual call.
            remote = client.prompts.retrieve(prompt_id=prompt_id)  # type: ignore[attr-defined]
            remote_text = getattr(remote, "template", None) or ""
        except Exception as e:  # noqa: BLE001
            diffs.append(f"{prompt_id}: fetch failed ({e})")
            continue
        if repo_text.strip() != remote_text.strip():
            diffs.append(
                f"{prompt_id}: DRIFT — repo and Portkey content differ "
                f"(repo={len(repo_text)} chars, remote={len(remote_text)} chars)"
            )
    return diffs


def _check_framework_vs_webhook() -> list[str]:
    """Run a probe input through framework guardrails directly and via the
    webhook. They should return identical verdicts.

    For local dev we hit the webhook via TestClient; in prod, point it at the
    deployed webhook URL.
    """
    from fastapi.testclient import TestClient
    from webhook.server import app

    client = TestClient(app)

    # Probe: a known-bad output with a hallucinated dollar figure.
    repo_root = Path(__file__).resolve().parent.parent
    with (repo_root / "tasks/precall_brief/tests/fixtures/loyal_customer.json").open() as f:
        input_data = json.load(f)

    bad_output = {
        "snapshot": {"current_premium": input_data["policy"]["current_premium"], "savings": 9999.00},
    }

    # Framework-direct check
    direct = build_guardrail(
        "numeric_values_match_input", {"allow_derived": True, "tolerance": 0.50}
    )
    framework_result = direct.check(
        bad_output, stage=GuardrailStage.OUTPUT, input_payload=input_data
    )

    # Webhook check
    payload = {
        "request": {"variables": {"input_json": input_data}},
        "response": {"choices": [{"message": {"content": json.dumps(bad_output)}}]},
    }
    r = client.post(
        "/guardrails/check",
        json=payload,
        headers={"x-task-id": "precall_brief", "x-mode": "enforce"},
    )
    webhook_passed = r.json().get("verdict", True)

    diffs: list[str] = []
    if framework_result.passed != webhook_passed:
        diffs.append(
            f"numeric_values_match_input: framework={framework_result.passed} "
            f"webhook={webhook_passed}"
        )
    return diffs


@click.command()
@click.option(
    "--mode",
    type=click.Choice(["repo_vs_portkey", "framework_vs_webhook", "all"]),
    default="all",
)
@click.option("--tasks-root", default="tasks")
def main(mode: str, tasks_root: str) -> None:
    all_diffs: list[str] = []

    if mode in ("repo_vs_portkey", "all"):
        diffs = _check_repo_vs_portkey(Path(tasks_root))
        for d in diffs:
            print(f"[repo_vs_portkey] {d}")
        all_diffs.extend(diffs)

    if mode in ("framework_vs_webhook", "all"):
        diffs = _check_framework_vs_webhook()
        for d in diffs:
            print(f"[framework_vs_webhook] {d}")
        all_diffs.extend(diffs)

    if all_diffs:
        print(f"\n{len(all_diffs)} drift issue(s) found.", file=sys.stderr)
        sys.exit(1)
    print("\nNo drift detected.")


if __name__ == "__main__":
    main()
