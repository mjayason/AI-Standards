"""CLI: run a task against a JSON input file.

Usage:
    python scripts/run_task.py <task_id> <input_json_path> [--mock] [--json]

In mock mode, no Portkey credentials are required and a synthetic response is
returned by the registered mock factory. Use this for local validation of the
plumbing — the prompt template is still rendered and metadata still extracted.
"""
from __future__ import annotations

import json
import sys
from dataclasses import asdict
from pathlib import Path

import click

# Make framework importable when running as a script
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from framework.logging_setup import configure_logging  # noqa: E402
from framework.portkey_client import PortkeyClient  # noqa: E402
from framework.runner import ReasoningTaskRunner  # noqa: E402


def _build_mock_factory(task_id: str):
    """Per-task mock responses that satisfy each output schema.

    In real testing you'd parameterize this from canned fixtures, but for the
    framework demo we hardcode minimally-valid outputs that exercise every
    guardrail (numeric_match in particular). All numbers come from the fixtures.
    """

    def factory(prompt_id: str, variables: dict, metadata: dict) -> str:
        input_json = variables["input_json"]
        if task_id == "precall_brief":
            return json.dumps({
                "snapshot": {
                    "customer_name_ref": "the customer",
                    "tenure_years": input_json["customer"]["tenure_years"],
                    "policy_summary": f"{input_json['policy']['line_of_business']} policy, 12-month term",
                    "current_premium": input_json["policy"]["current_premium"],
                    "new_premium": input_json["policy"]["new_premium"],
                    "change_display": f"+${input_json['policy']['change_amount']:.0f} (+{input_json['policy']['change_percent']:.1f}%)",
                    "effective_date": input_json["policy"]["effective_date"],
                },
                "read_on_customer": {
                    "segment": "loyal_low_claim",
                    "segment_evidence": "18-year tenure with no claims in the last 36 months and high lifetime value.",
                    "emotional_starting_point": "Likely to feel that loyalty is being penalized. Will expect a substantive explanation, not corporate language.",
                },
                "why_premium_changed": [
                    {"driver": "Statewide auto rates were filed higher due to repair and medical cost inflation.", "approximate_dollar_impact": 178.00},
                    {"driver": "Claims activity in this ZIP code rose, largely from severe weather events.", "approximate_dollar_impact": 92.00},
                    {"driver": "Catastrophe reinsurance costs for the state increased this cycle.", "approximate_dollar_impact": 44.00},
                ],
                "options_to_offer": [
                    {"rank": 1, "option_id": "OPT_COVERAGE_REVIEW", "label": "Coverage review with agent", "dollar_impact": 0.00, "trade_off": "May identify reducible coverages on older vehicles; no automatic savings.", "why_this_customer": "Long tenure means coverage may not match current vehicles or driving needs."},
                    {"rank": 2, "option_id": "OPT_TELEMATICS", "label": "Enroll in telematics program", "dollar_impact": -130.00, "trade_off": "Driving behavior is monitored for 90 days; rate could go up if driving is risky.", "why_this_customer": "Zero claims in 36 months suggests safe driving that would be rewarded."},
                    {"rank": 3, "option_id": "OPT_DED_500_TO_1000", "label": "Raise collision deductible from $500 to $1,000", "dollar_impact": -142.00, "trade_off": "Customer pays more out-of-pocket if they have a covered loss.", "why_this_customer": "High lifetime value customer can likely absorb the higher deductible if a loss occurs."},
                ],
                "likely_objections": [
                    {"objection": "I've been with you 18 years and never filed a claim.", "emotion_underneath": "Feeling unrewarded for loyalty.", "response": "Acknowledge the 18-year relationship explicitly. Explain the increase reflects costs that affect every policyholder in the state, not their record. Walk through the safe-driver discount already applied.", "pivot_to": "tenure_acknowledgment"},
                    {"objection": "I'll just shop around.", "emotion_underneath": "Frustration looking for validation, not a threat yet.", "response": "Don't argue. Offer the coverage review and the telematics option as concrete ways to bring premium down before they decide.", "pivot_to": "OPT_TELEMATICS"},
                ],
                "watch_outs": [
                    "High lifetime value customer — escalate before losing.",
                    "No claims history means a generic 'claims-drove-this' explanation will fail.",
                ],
                "do_not_say": [
                    "There's nothing I can do about it.",
                    "Everyone's premium is going up.",
                ],
                "authority_reminder": {
                    "max_retention_credit": 75.00,
                    "can_offer_without_escalation": ["loyalty credit", "deductible adjustment", "telematics enrollment", "billing change"],
                    "must_escalate_if": ["customer requests credit above $75", "customer threatens to cancel multi-policy"],
                },
                "compliance_flags": {
                    "required_disclosures": ["This rate change was approved by the Texas Department of Insurance."],
                    "state_specific_notes": ["Texas requires written notice of premium increases at least 30 days before effective date."],
                },
                "retention_risk": {
                    "score_band": "medium",
                    "primary_lever": "Acknowledge the 18-year tenure explicitly and offer the telematics option as the most likely savings path.",
                },
            })
        elif task_id == "fnol_brief":
            return json.dumps({
                "snapshot": {
                    "claim_id": input_json["claim"]["claim_id"],
                    "lob": input_json["claim"]["line_of_business"],
                    "severity_estimate": input_json["claim"]["severity_estimate"],
                    "estimated_damages": input_json["loss_details"]["estimated_damages"],
                },
                "coverage_read": {
                    "likely_applicable_coverages": ["collision"],
                    "deductible": input_json["policy_summary"]["deductible"],
                    "caveats": ["Confirm loss date falls within policy effective dates.", "Verify other driver's liability before subrogation."],
                },
                "investigation_priorities": [
                    "Obtain repair estimate from approved shop.",
                    "Collect police report and other driver's insurance information.",
                    "Take scene and damage photos.",
                ],
                "red_flags": [],
                "next_steps": [
                    "Schedule first contact with insured within 24 hours.",
                    "Open subrogation file given third party at fault.",
                ],
            })
        else:
            return json.dumps({"_mock": True})

    return factory


@click.command()
@click.argument("task_id")
@click.argument("input_path", type=click.Path(exists=True))
@click.option("--mock", is_flag=True, help="Use mock Portkey responses (no API key needed).")
@click.option("--json", "json_only", is_flag=True, help="Print only the JSON output.")
@click.option("--tasks-root", default="tasks", help="Tasks root directory.")
def main(task_id: str, input_path: str, mock: bool, json_only: bool, tasks_root: str) -> None:
    configure_logging(level="INFO" if not json_only else "WARNING")
    with open(input_path) as f:
        input_data = json.load(f)

    if mock:
        client = PortkeyClient(mock=True, mock_response_factory=_build_mock_factory(task_id))
    else:
        client = PortkeyClient()

    runner = ReasoningTaskRunner(task_id=task_id, tasks_root=tasks_root, portkey_client=client)
    result = runner.execute(input_data)

    if json_only:
        if result.output is not None:
            print(json.dumps(result.output, indent=2))
        else:
            print(json.dumps({"error": result.error, "rejection_reasons": result.rejection_reasons}, indent=2))
        sys.exit(0 if result.status.value == "success" else 1)

    print("=" * 80)
    print(f"STATUS: {result.status.value}")
    print(f"TASK:   {result.trace.task_id} v{result.trace.task_version}")
    print(f"MODEL:  {result.trace.model_used}")
    print(f"TRACE:  {result.trace.portkey_trace_id}")
    print(f"COST:   ${result.trace.cost_usd or 0:.4f} | TOKENS in/out: {result.trace.input_tokens}/{result.trace.output_tokens} | LATENCY: {result.trace.latency_ms}ms")
    print(f"TAGS:   {result.trace.metadata_tags}")
    print("-" * 80)
    print("GUARDRAILS:")
    for g in result.trace.guardrails:
        mark = "✓" if g.passed else "✗"
        print(f"  {mark} [{g.stage.value}] {g.name}: {g.detail}")
    print("-" * 80)
    if result.rejection_reasons:
        print("REJECTIONS:")
        for r in result.rejection_reasons:
            print(f"  - {r}")
        print("-" * 80)
    if result.output is not None:
        print("OUTPUT:")
        print(json.dumps(result.output, indent=2))
    sys.exit(0 if result.status.value == "success" else 1)


if __name__ == "__main__":
    main()
