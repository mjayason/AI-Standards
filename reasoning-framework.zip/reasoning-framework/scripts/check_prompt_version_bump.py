"""Enforce: if prompt.md changed in this PR, task.yaml version must be bumped.

Without this rule, the audit story falls apart:
    - "Which prompt produced this brief last March?" → "version 7"
    - "What did version 7 say?" → "depends when you ran it"

We diff against the merge base, find any prompt.md that changed, and require
its task.yaml `version` to have changed too.

Usage in CI:
    python scripts/check_prompt_version_bump.py --base-ref origin/main

Locally:
    python scripts/check_prompt_version_bump.py --base-ref HEAD~1
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import click
import yaml


def _git(*args: str) -> str:
    result = subprocess.run(
        ["git", *args], capture_output=True, text=True, check=False
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed: {result.stderr}")
    return result.stdout


def _changed_files(base_ref: str) -> set[Path]:
    out = _git("diff", "--name-only", f"{base_ref}...HEAD")
    return {Path(line.strip()) for line in out.splitlines() if line.strip()}


def _read_yaml_at_ref(ref: str, path: Path) -> dict | None:
    """Read the version of a file at a given git ref. Returns None if file didn't exist."""
    result = subprocess.run(
        ["git", "show", f"{ref}:{path}"],
        capture_output=True, text=True, check=False,
    )
    if result.returncode != 0:
        return None
    try:
        return yaml.safe_load(result.stdout)
    except yaml.YAMLError:
        return None


@click.command()
@click.option("--base-ref", default="origin/main", help="Base ref to diff against.")
@click.option("--tasks-root", default="tasks")
def main(base_ref: str, tasks_root: str) -> None:
    changed = _changed_files(base_ref)
    tasks_root_path = Path(tasks_root)
    violations: list[str] = []

    # Group changes by task directory.
    tasks_with_prompt_changes: set[str] = set()
    tasks_with_yaml_changes: set[str] = set()
    tasks_with_schema_changes: set[str] = set()

    for f in changed:
        if not f.is_relative_to(tasks_root_path):
            continue
        parts = f.relative_to(tasks_root_path).parts
        if len(parts) < 2:
            continue
        task_id = parts[0]
        filename = parts[1]
        if filename == "prompt.md":
            tasks_with_prompt_changes.add(task_id)
        elif filename == "task.yaml":
            tasks_with_yaml_changes.add(task_id)
        elif filename in ("input_schema.json", "output_schema.json"):
            tasks_with_schema_changes.add(task_id)

    all_touched = (
        tasks_with_prompt_changes
        | tasks_with_yaml_changes
        | tasks_with_schema_changes
    )

    for task_id in sorted(all_touched):
        task_yaml = tasks_root_path / task_id / "task.yaml"
        current = yaml.safe_load(task_yaml.read_text()) if task_yaml.exists() else None
        previous = _read_yaml_at_ref(base_ref, task_yaml)

        current_version = current.get("version") if current else None
        previous_version = previous.get("version") if previous else None

        prompt_changed = task_id in tasks_with_prompt_changes
        schema_changed = task_id in tasks_with_schema_changes

        if prompt_changed or schema_changed:
            if previous is None:
                # New task — fine, version starts wherever.
                print(f"NEW   {task_id}: prompt/schema added, initial version={current_version}")
                continue
            if current_version == previous_version:
                kind = "prompt" if prompt_changed else "schema"
                violations.append(
                    f"{task_id}: {kind} changed but version stayed at {current_version}. "
                    f"Bump task.yaml `version` to make changes auditable."
                )
            else:
                print(
                    f"OK    {task_id}: {previous_version} → {current_version} "
                    f"(prompt_changed={prompt_changed}, schema_changed={schema_changed})"
                )

    if violations:
        print("\nVersion-bump check FAILED:\n", file=sys.stderr)
        for v in violations:
            print(f"  ✗ {v}", file=sys.stderr)
        sys.exit(1)

    print("\nVersion-bump check passed.")


if __name__ == "__main__":
    main()
