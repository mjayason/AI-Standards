"""Sync local prompts and configs to Portkey.

This is the disciplined version of prompt management: prompts live in git, are
reviewed in PRs, and are pushed to Portkey on merge. The repo is the source of
truth — never edit prompts in the Portkey UI for production tasks.

Usage:
    python scripts/sync_portkey.py [--dry-run]

Implementation note: the Portkey SDK's prompt management API surface varies
slightly by version; we use a thin try/except around the documented methods.
For local dev, --dry-run prints what would be pushed without making API calls.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import click
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def _gather_prompts(tasks_root: Path) -> list[dict]:
    out = []
    for task_dir in tasks_root.iterdir():
        if not task_dir.is_dir():
            continue
        task_yaml = task_dir / "task.yaml"
        prompt_md = task_dir / "prompt.md"
        if not (task_yaml.exists() and prompt_md.exists()):
            continue
        with task_yaml.open() as f:
            cfg = yaml.safe_load(f)
        out.append({
            "prompt_id": cfg["prompt"]["portkey_prompt_id"],
            "version": cfg["version"],
            "task_id": cfg["task_id"],
            "text": prompt_md.read_text(),
        })
    return out


def _gather_configs(configs_dir: Path) -> list[dict]:
    out = []
    for path in configs_dir.glob("*.json"):
        with path.open() as f:
            cfg = json.load(f)
        out.append({"config_id": cfg["id"], "body": cfg})
    return out


@click.command()
@click.option("--dry-run", is_flag=True, help="Print what would be pushed.")
@click.option("--tasks-root", default="tasks")
@click.option("--configs-root", default="portkey_config/configs")
def main(dry_run: bool, tasks_root: str, configs_root: str) -> None:
    prompts = _gather_prompts(Path(tasks_root))
    configs = _gather_configs(Path(configs_root))

    print(f"Found {len(prompts)} prompts, {len(configs)} configs.")

    if dry_run:
        for p in prompts:
            print(f"  [prompt] {p['prompt_id']} v{p['version']} (task={p['task_id']}, {len(p['text'])} chars)")
        for c in configs:
            print(f"  [config] {c['config_id']}")
        print("\nDry-run only. No API calls made.")
        return

    api_key = os.getenv("PORTKEY_API_KEY")
    if not api_key:
        print("PORTKEY_API_KEY not set", file=sys.stderr)
        sys.exit(1)

    try:
        from portkey_ai import Portkey  # type: ignore
    except ImportError:
        print("portkey-ai not installed", file=sys.stderr)
        sys.exit(1)

    client = Portkey(api_key=api_key)
    # Real Portkey calls would go here. Shape:
    #   client.prompts.create(name=p['prompt_id'], template=p['text'], ...)
    #   client.configs.upsert(id=c['config_id'], body=c['body'])
    # The exact methods depend on SDK version — confirm against current Portkey docs.
    print("Push not implemented in this template — confirm SDK methods against your Portkey version.")


if __name__ == "__main__":
    main()
