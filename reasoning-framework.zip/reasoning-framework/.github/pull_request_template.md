<!-- Pull-request template. Auto-applied to every PR. -->

## What changed

<!-- Brief description. If a prompt or schema changed, name the task. -->

## Type of change

- [ ] New task
- [ ] Prompt change to existing task (version bumped in `task.yaml`)
- [ ] Schema change (backwards compatibility considered)
- [ ] Guardrail config change
- [ ] Framework code (requires @org/framework-team review)
- [ ] Webhook code (requires @org/framework-team + @org/platform-security)
- [ ] CI/scripts only

## Checklist for prompt or schema changes

- [ ] `task.yaml` `version` is bumped
- [ ] Fixtures in `tasks/<id>/tests/fixtures/` still pass (`python scripts/run_fixtures.py <id> --mock`)
- [ ] If output schema changed, downstream consumers (agent desktop, etc.) are notified
- [ ] Compliance reviewer requested (CI does this automatically on prompt changes)

## Checklist for framework changes

- [ ] No task-specific logic introduced (if you find yourself writing `if task_id == ...`, redesign)
- [ ] New guardrails added to the registry with documented params
- [ ] Tests added in `tests/`
- [ ] Webhook still passes the same inputs (the drift check will catch this, but verify locally)

## How verified

<!-- Paste outputs from local runs, fixture replays, or screenshots if relevant. -->
