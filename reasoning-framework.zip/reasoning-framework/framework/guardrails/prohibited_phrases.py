"""prohibited_phrases: reject if any banned phrase appears in the output.

Params:
    source: dotted path into input where the deny-list lives, e.g.
        "input.compliance.prohibited_phrases". This lets compliance configure
        per-state deny-lists in the input data, not in the prompt.
    static: list[str] (optional) — additional always-prohibited phrases.
    case_sensitive: bool (default False)
    exclude_fields: list[str] (optional) — top-level output keys to skip.
        Use this for fields whose purpose is to list bad phrases (e.g.
        "do_not_say"), so the guardrail doesn't flag itself.

Matching: substring, case-insensitive by default. Whole-word boundaries are
NOT enforced because brand/legal phrases are often multi-word.
"""
from __future__ import annotations

from typing import Any

from framework.guardrails.base import Guardrail, register_guardrail
from framework.metadata import get_by_path
from framework.types import GuardrailResult, GuardrailStage


def _all_text(node: Any, exclude_top_keys: set[str] | None = None) -> str:
    """Concatenate all string values in a nested structure, separated by newlines.

    When exclude_top_keys is set and node is a dict, those top-level keys are
    skipped entirely (and not recursed into).
    """
    if isinstance(node, str):
        return node
    if isinstance(node, dict):
        return "\n".join(
            _all_text(v)
            for k, v in node.items()
            if not exclude_top_keys or k not in exclude_top_keys
        )
    if isinstance(node, list):
        return "\n".join(_all_text(v) for v in node)
    return ""


@register_guardrail
class ProhibitedPhrasesGuardrail(Guardrail):
    name = "prohibited_phrases"
    supports_stages = (GuardrailStage.OUTPUT,)

    def check(
        self,
        payload: Any,
        *,
        stage: GuardrailStage,
        input_payload: dict[str, Any],
    ) -> GuardrailResult:
        phrases: list[str] = list(self.params.get("static", []))
        source = self.params.get("source")
        if source:
            wrapped = {"input": input_payload}
            value = get_by_path(wrapped, source)
            if isinstance(value, list):
                phrases.extend(str(p) for p in value)

        if not phrases:
            return GuardrailResult(
                name=self.name, stage=stage, passed=True,
                detail="no phrases configured",
            )

        case_sensitive = bool(self.params.get("case_sensitive", False))
        exclude_fields = set(self.params.get("exclude_fields", []) or [])
        haystack = _all_text(payload, exclude_top_keys=exclude_fields)
        if not case_sensitive:
            haystack_cmp = haystack.lower()
        else:
            haystack_cmp = haystack

        found = []
        for phrase in phrases:
            needle = phrase if case_sensitive else phrase.lower()
            if needle and needle in haystack_cmp:
                found.append(phrase)

        if found:
            return GuardrailResult(
                name=self.name, stage=stage, passed=False,
                detail=f"prohibited phrases present: {found}",
            )
        return GuardrailResult(name=self.name, stage=stage, passed=True)
