"""referenced_ids_exist: every ID referenced in output must exist in input.

Params:
    references: list of {output_path, input_path, id_field} mappings.
        output_path: dotted path to a list in the output
        input_path: dotted path to a list in the input
        id_field: the field name within each list item to compare

Example:
    references:
      - output_path: options_to_offer
        input_path: options_catalog
        id_field: option_id
"""
from __future__ import annotations

from typing import Any

from framework.guardrails.base import Guardrail, register_guardrail
from framework.metadata import get_by_path
from framework.types import GuardrailResult, GuardrailStage


@register_guardrail
class ReferencedIdsGuardrail(Guardrail):
    name = "referenced_ids_exist"
    supports_stages = (GuardrailStage.OUTPUT,)

    def check(
        self,
        payload: Any,
        *,
        stage: GuardrailStage,
        input_payload: dict[str, Any],
    ) -> GuardrailResult:
        references = self.params.get("references") or []
        if not references:
            return GuardrailResult(
                name=self.name, stage=stage, passed=False,
                detail="'references' param required",
            )

        wrapped_in = {"input": input_payload}
        wrapped_out = {"output": payload}
        violations: list[str] = []

        for ref in references:
            output_path = ref["output_path"]
            input_path = ref["input_path"]
            id_field = ref["id_field"]

            input_list = get_by_path(wrapped_in, f"input.{input_path}") or []
            output_list = get_by_path(wrapped_out, f"output.{output_path}") or []

            valid_ids = {
                item.get(id_field)
                for item in input_list
                if isinstance(item, dict) and item.get(id_field) is not None
            }
            for i, item in enumerate(output_list):
                if not isinstance(item, dict):
                    continue
                ref_id = item.get(id_field)
                if ref_id is None:
                    continue
                if ref_id not in valid_ids:
                    violations.append(
                        f"{output_path}[{i}].{id_field}='{ref_id}' not in input.{input_path}"
                    )

        if violations:
            return GuardrailResult(
                name=self.name, stage=stage, passed=False,
                detail="; ".join(violations[:5]),
            )
        return GuardrailResult(name=self.name, stage=stage, passed=True)
