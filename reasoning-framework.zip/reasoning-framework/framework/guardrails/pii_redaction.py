"""pii_redaction: redact PII before sending to the model, restore after.

This guardrail runs on INPUT and mutates the payload, replacing PII fields with
tokens. The runner stores the mapping and the OUTPUT runner re-hydrates tokens
back to real values before guardrails check the output and before delivery.

Params:
    fields: list of dotted paths into input that contain PII.
        e.g. ["customer.full_name", "customer.email", "customer.phone"]

The replacement token has the form __PII_<index>__ which is unlikely to appear
in model output for any other reason.
"""
from __future__ import annotations

from typing import Any

from framework.guardrails.base import Guardrail, register_guardrail
from framework.metadata import get_by_path
from framework.types import GuardrailResult, GuardrailStage


def _set_by_path(payload: dict[str, Any], path: str, value: Any) -> None:
    parts = path.split(".")
    cur: Any = payload
    for part in parts[:-1]:
        if not isinstance(cur, dict) or part not in cur:
            return
        cur = cur[part]
    if isinstance(cur, dict) and parts[-1] in cur:
        cur[parts[-1]] = value


def _deep_copy(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _deep_copy(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_deep_copy(v) for v in obj]
    return obj


@register_guardrail
class PiiRedactionGuardrail(Guardrail):
    name = "pii_redaction"
    supports_stages = (GuardrailStage.INPUT,)

    def check(
        self,
        payload: Any,
        *,
        stage: GuardrailStage,
        input_payload: dict[str, Any],
    ) -> GuardrailResult:
        fields = self.params.get("fields") or []
        if not fields or not isinstance(payload, dict):
            return GuardrailResult(name=self.name, stage=stage, passed=True)

        new_payload = _deep_copy(payload)
        mapping: dict[str, str] = {}
        wrapped = {"_": new_payload}

        for idx, field_path in enumerate(fields):
            value = get_by_path(wrapped, f"_.{field_path}")
            if value is None:
                continue
            token = f"__PII_{idx}__"
            mapping[token] = str(value)
            _set_by_path(new_payload, field_path, token)

        # Attach the mapping under a reserved key so the runner can re-hydrate.
        new_payload["__pii_mapping__"] = mapping

        return GuardrailResult(
            name=self.name, stage=stage, passed=True,
            mutated_payload=new_payload,
            detail=f"redacted {len(mapping)} field(s)",
        )
