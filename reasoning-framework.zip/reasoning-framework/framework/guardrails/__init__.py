"""Guardrails package. Importing this module registers all built-ins."""
from framework.guardrails.base import (
    Guardrail,
    build_guardrail,
    register_guardrail,
    registered_names,
)

# Import all built-ins so @register_guardrail fires.
from framework.guardrails import (  # noqa: F401
    json_only,
    schema_validation,
    word_count,
    prohibited_phrases,
    required_phrases,
    numeric_match,
    referenced_ids,
    pii_redaction,
)

__all__ = [
    "Guardrail",
    "build_guardrail",
    "register_guardrail",
    "registered_names",
]
