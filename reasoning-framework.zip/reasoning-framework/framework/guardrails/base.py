"""Guardrail base class and registry.

Guardrails are the post-LLM compliance layer. They run deterministically against
the output (or input) and either pass, mutate, or reject the payload.

Task authors don't write guardrail code for the common cases — they reference
guardrails by name from task.yaml and pass parameters.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Callable

from framework.exceptions import GuardrailConfigError
from framework.types import GuardrailResult, GuardrailStage


class Guardrail(ABC):
    """Subclass and register via @register_guardrail."""

    name: str = ""
    supports_stages: tuple[GuardrailStage, ...] = (GuardrailStage.OUTPUT,)

    def __init__(self, params: dict[str, Any]):
        self.params = params

    @abstractmethod
    def check(
        self,
        payload: Any,
        *,
        stage: GuardrailStage,
        input_payload: dict[str, Any],
    ) -> GuardrailResult:
        """Run the guardrail.

        Args:
            payload: The thing being checked — input or model output.
            stage: input or output, in case behavior differs.
            input_payload: Always the original input, so output guardrails can
                cross-check against input (e.g. dollar figures match).
        """


_REGISTRY: dict[str, type[Guardrail]] = {}


def register_guardrail(cls: type[Guardrail]) -> type[Guardrail]:
    if not cls.name:
        raise GuardrailConfigError(f"Guardrail class {cls.__name__} has no name")
    if cls.name in _REGISTRY:
        raise GuardrailConfigError(f"Duplicate guardrail name: {cls.name}")
    _REGISTRY[cls.name] = cls
    return cls


def build_guardrail(name: str, params: dict[str, Any]) -> Guardrail:
    if name not in _REGISTRY:
        raise GuardrailConfigError(
            f"Unknown guardrail: {name}. Registered: {sorted(_REGISTRY)}"
        )
    return _REGISTRY[name](params)


def registered_names() -> list[str]:
    return sorted(_REGISTRY)
