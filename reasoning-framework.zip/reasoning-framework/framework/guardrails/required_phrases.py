"""required_phrases_present: enforce verbatim disclosures appear in output.

Params:
    source: dotted path into input listing required strings, e.g.
        "input.compliance.required_disclosures".
    target_field: dotted path into output where the disclosures must live, e.g.
        "compliance_flags.required_disclosures". Optional — defaults to scanning
        the entire output.

Failure: missing disclosure, or disclosure altered (substring match required).
"""
from __future__ import annotations

from typing import Any

from framework.guardrails.base import Guardrail, register_guardrail
from framework.metadata import get_by_path
from framework.types import GuardrailResult, GuardrailStage


def _all_text(node: Any) -> str:
    if isinstance(node, str):
        return node
    if isinstance(node, dict):
        return "\n".join(_all_text(v) for v in node.values())
    if isinstance(node, list):
        return "\n".join(_all_text(v) for v in node)
    return ""


@register_guardrail
class RequiredPhrasesPresentGuardrail(Guardrail):
    name = "required_phrases_present"
    supports_stages = (GuardrailStage.OUTPUT,)

    def check(
        self,
        payload: Any,
        *,
        stage: GuardrailStage,
        input_payload: dict[str, Any],
    ) -> GuardrailResult:
        source = self.params.get("source")
        if not source:
            return GuardrailResult(
                name=self.name, stage=stage, passed=False,
                detail="'source' param required",
            )
        wrapped_in = {"input": input_payload}
        required = get_by_path(wrapped_in, source) or []
        if not isinstance(required, list) or not required:
            return GuardrailResult(
                name=self.name, stage=stage, passed=True,
                detail="no required phrases",
            )

        target_field = self.params.get("target_field")
        if target_field:
            wrapped_out = {"output": payload}
            scope = get_by_path(wrapped_out, f"output.{target_field}")
            haystack = _all_text(scope)
        else:
            haystack = _all_text(payload)

        missing = [r for r in required if r not in haystack]
        if missing:
            return GuardrailResult(
                name=self.name, stage=stage, passed=False,
                detail=f"missing required disclosures: {missing}",
            )
        return GuardrailResult(name=self.name, stage=stage, passed=True)
