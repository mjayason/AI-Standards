"""word_count: enforce maximum word count on the output.

Params:
    max: int — maximum total words
    fields: list[str] (optional) — only count specified dotted-path fields,
        rather than the full serialized output. If omitted, count words in
        every string value recursively.
"""
from __future__ import annotations

import re
from typing import Any

from framework.guardrails.base import Guardrail, register_guardrail
from framework.metadata import get_by_path
from framework.types import GuardrailResult, GuardrailStage


def _count_words(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text))


def _walk_strings(node: Any) -> list[str]:
    if isinstance(node, str):
        return [node]
    if isinstance(node, dict):
        out = []
        for v in node.values():
            out.extend(_walk_strings(v))
        return out
    if isinstance(node, list):
        out = []
        for v in node:
            out.extend(_walk_strings(v))
        return out
    return []


@register_guardrail
class WordCountGuardrail(Guardrail):
    name = "word_count"
    supports_stages = (GuardrailStage.OUTPUT,)

    def check(
        self,
        payload: Any,
        *,
        stage: GuardrailStage,
        input_payload: dict[str, Any],
    ) -> GuardrailResult:
        max_words = self.params.get("max")
        if max_words is None:
            return GuardrailResult(
                name=self.name, stage=stage, passed=False,
                detail="word_count requires 'max' param",
            )

        fields = self.params.get("fields")
        if fields:
            wrapped = {"output": payload}
            strings: list[str] = []
            for field in fields:
                value = get_by_path(wrapped, f"output.{field}")
                strings.extend(_walk_strings(value))
        else:
            strings = _walk_strings(payload)

        total = sum(_count_words(s) for s in strings)
        if total > max_words:
            return GuardrailResult(
                name=self.name, stage=stage, passed=False,
                detail=f"word count {total} exceeds max {max_words}",
            )
        return GuardrailResult(
            name=self.name, stage=stage, passed=True,
            detail=f"{total}/{max_words} words",
        )
