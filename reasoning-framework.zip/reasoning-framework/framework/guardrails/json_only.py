"""json_only: ensure output is parseable JSON.

Models sometimes wrap JSON in ```json fences or add a preamble. This guardrail
strips common wrappers and parses; on failure, rejects. On success, returns the
parsed dict via mutated_payload so downstream guardrails work on structured data.
"""
from __future__ import annotations

import json
import re
from typing import Any

from framework.guardrails.base import Guardrail, register_guardrail
from framework.types import GuardrailResult, GuardrailStage


@register_guardrail
class JsonOnlyGuardrail(Guardrail):
    name = "json_only"
    supports_stages = (GuardrailStage.OUTPUT,)

    def check(
        self,
        payload: Any,
        *,
        stage: GuardrailStage,
        input_payload: dict[str, Any],
    ) -> GuardrailResult:
        if isinstance(payload, dict):
            # Already parsed upstream.
            return GuardrailResult(
                name=self.name, stage=stage, passed=True, detail="already parsed"
            )

        if not isinstance(payload, str):
            return GuardrailResult(
                name=self.name,
                stage=stage,
                passed=False,
                detail=f"expected string output, got {type(payload).__name__}",
            )

        text = payload.strip()
        # Strip common markdown code fences.
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)

        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as e:
            return GuardrailResult(
                name=self.name,
                stage=stage,
                passed=False,
                detail=f"output is not valid JSON: {e.msg} at pos {e.pos}",
            )

        return GuardrailResult(
            name=self.name,
            stage=stage,
            passed=True,
            mutated_payload=parsed,
        )
