"""numeric_values_match_input: every numeric value in the output must trace to input.

This is the guardrail you cannot skip for regulated comms. It catches the
single highest-risk LLM failure mode: hallucinating a dollar figure.

Algorithm:
    1. Walk the output, extract every number (int/float, or numeric string
       matching $X.XX or X% patterns).
    2. Walk the input, build a set of allowed numeric values.
    3. For each output number, require it to match an input number within
       tolerance, OR be derivable as a simple arithmetic combination
       (sum, difference) of two input numbers — this allows the model to
       state, e.g., a percentage change computed from old/new premium.
    4. Reject if any number doesn't trace.

Params:
    tolerance: float — absolute tolerance for float comparison. Default 0.01.
    allow_derived: bool — allow output values that match (a+b), (a-b),
        (a*100/b) (percent change). Default True.
    ignore_fields: list[str] — output paths whose numbers don't need to
        trace (e.g. ranks, counts). Default empty.
"""
from __future__ import annotations

import re
from typing import Any

from framework.guardrails.base import Guardrail, register_guardrail
from framework.metadata import get_by_path
from framework.types import GuardrailResult, GuardrailStage


_NUMBER_RE = re.compile(
    r"-?\$?\d{1,3}(?:,\d{3})*(?:\.\d+)?%?|-?\$?\d+(?:\.\d+)?%?"
)


def _parse_token(tok: str) -> float | None:
    s = tok.replace("$", "").replace(",", "").rstrip("%")
    try:
        return float(s)
    except ValueError:
        return None


def _extract_numbers_from_string(text: str) -> list[float]:
    nums = []
    for match in _NUMBER_RE.findall(text):
        val = _parse_token(match)
        if val is not None:
            nums.append(val)
    return nums


def _walk_numbers(
    node: Any, path: str = ""
) -> list[tuple[str, float]]:
    out: list[tuple[str, float]] = []
    if isinstance(node, bool):
        return out  # bools are ints in Python; skip
    if isinstance(node, (int, float)):
        out.append((path or "<root>", float(node)))
        return out
    if isinstance(node, str):
        for n in _extract_numbers_from_string(node):
            out.append((path or "<root>", n))
        return out
    if isinstance(node, dict):
        for k, v in node.items():
            out.extend(_walk_numbers(v, f"{path}.{k}" if path else k))
        return out
    if isinstance(node, list):
        for i, v in enumerate(node):
            out.extend(_walk_numbers(v, f"{path}[{i}]"))
        return out
    return out


def _is_close(a: float, b: float, tol: float) -> bool:
    return abs(a - b) <= tol


@register_guardrail
class NumericMatchGuardrail(Guardrail):
    name = "numeric_values_match_input"
    supports_stages = (GuardrailStage.OUTPUT,)

    def check(
        self,
        payload: Any,
        *,
        stage: GuardrailStage,
        input_payload: dict[str, Any],
    ) -> GuardrailResult:
        tol = float(self.params.get("tolerance", 0.01))
        allow_derived = bool(self.params.get("allow_derived", True))
        ignore_fields = set(self.params.get("ignore_fields", []))

        input_numbers = [n for _, n in _walk_numbers(input_payload)]
        # Trivial whole numbers are typically ranks, counts, indices — allow.
        trivial = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0}

        unmatched: list[tuple[str, float]] = []
        for path, n in _walk_numbers(payload):
            # Strip leading "output." pattern if used in ignore_fields
            normalized = path
            if any(normalized == f or normalized.startswith(f + ".") or normalized.startswith(f + "[") for f in ignore_fields):
                continue
            if n in trivial:
                continue
            if any(_is_close(n, m, tol) for m in input_numbers):
                continue
            if allow_derived and self._is_derived(n, input_numbers, tol):
                continue
            unmatched.append((path, n))

        if unmatched:
            sample = ", ".join(f"{p}={v}" for p, v in unmatched[:5])
            return GuardrailResult(
                name=self.name, stage=stage, passed=False,
                detail=f"output contains {len(unmatched)} number(s) not traceable to input: {sample}",
            )
        return GuardrailResult(name=self.name, stage=stage, passed=True)

    def _is_derived(self, n: float, inputs: list[float], tol: float) -> bool:
        # Check pairwise sums, differences, and (a-b)/b*100 percent-change.
        for i, a in enumerate(inputs):
            for b in inputs[i:]:
                if _is_close(n, a + b, tol):
                    return True
                if _is_close(n, abs(a - b), tol):
                    return True
                if b != 0 and _is_close(n, round((a - b) / b * 100, 1), max(tol, 0.1)):
                    return True
                if a != 0 and _is_close(n, round((b - a) / a * 100, 1), max(tol, 0.1)):
                    return True
        return False
