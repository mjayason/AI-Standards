"""schema_validation: validate payload against the task's input or output schema.

The schema reference is implicit — the runner injects the right schema based on stage.
"""
from __future__ import annotations

from typing import Any

from jsonschema import Draft202012Validator

from framework.guardrails.base import Guardrail, register_guardrail
from framework.types import GuardrailResult, GuardrailStage


@register_guardrail
class SchemaValidationGuardrail(Guardrail):
    name = "schema_validation"
    supports_stages = (GuardrailStage.INPUT, GuardrailStage.OUTPUT)

    def check(
        self,
        payload: Any,
        *,
        stage: GuardrailStage,
        input_payload: dict[str, Any],
    ) -> GuardrailResult:
        schema = self.params.get("_schema")
        if schema is None:
            return GuardrailResult(
                name=self.name,
                stage=stage,
                passed=False,
                detail="schema not injected (framework bug)",
            )
        validator = Draft202012Validator(schema)
        errors = list(validator.iter_errors(payload))
        if not errors:
            return GuardrailResult(name=self.name, stage=stage, passed=True)
        formatted = []
        for err in errors[:10]:
            path = ".".join(str(p) for p in err.absolute_path) or "<root>"
            formatted.append(f"{path}: {err.message}")
        return GuardrailResult(
            name=self.name,
            stage=stage,
            passed=False,
            detail="; ".join(formatted),
        )
