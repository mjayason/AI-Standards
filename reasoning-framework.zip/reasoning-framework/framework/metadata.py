"""Extract metadata tags from input using dotted paths.

Tags are sent to Portkey as request metadata so observability dashboards can
slice cost/latency/quality by lob, state, etc. without per-task plumbing.
"""
from __future__ import annotations

from typing import Any

from framework.config import MetadataTagSpec


def get_by_path(payload: dict[str, Any], path: str) -> Any:
    """Return the value at a dotted path, or None if missing.

    Path is relative to the wrapper: 'input.policy.lob' means
    payload['input']['policy']['lob']. Missing keys return None rather than
    raising; metadata extraction must never break a task run.
    """
    cur: Any = payload
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return None
    return cur


def extract_tags(
    input_payload: dict[str, Any], specs: list[MetadataTagSpec]
) -> dict[str, Any]:
    wrapped = {"input": input_payload}
    tags: dict[str, Any] = {}
    for spec in specs:
        value = get_by_path(wrapped, spec.path)
        if value is not None:
            # Portkey metadata values must be strings
            tags[spec.as_name] = str(value)
    return tags
