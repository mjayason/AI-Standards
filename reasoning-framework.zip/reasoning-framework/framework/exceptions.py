"""Framework exceptions. Specific enough to handle distinctly, not so specific they multiply."""


class FrameworkError(Exception):
    """Base for all framework errors."""


class TaskConfigError(FrameworkError):
    """Task config is malformed or references missing files."""


class SchemaValidationError(FrameworkError):
    """Input or output failed JSON Schema validation."""
    def __init__(self, message: str, errors: list[str]):
        super().__init__(message)
        self.errors = errors


class GuardrailRejection(FrameworkError):
    """One or more guardrails rejected the payload."""
    def __init__(self, message: str, reasons: list[str]):
        super().__init__(message)
        self.reasons = reasons


class PortkeyCallError(FrameworkError):
    """Portkey gateway call failed after retries."""


class GuardrailConfigError(FrameworkError):
    """Guardrail referenced in task.yaml is unknown or misconfigured."""
