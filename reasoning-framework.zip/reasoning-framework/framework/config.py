"""Loads and validates task.yaml. Failing here is better than failing in production."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from framework.exceptions import TaskConfigError


@dataclass
class GuardrailSpec:
    name: str
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class SubTaskSpec:
    task_id: str
    cache_key_template: str
    cache_ttl_seconds: int
    inject_as: str  # dotted path into input, e.g. "input.book_drivers.plain_language"


@dataclass
class MetadataTagSpec:
    path: str  # dotted path into input
    as_name: str


@dataclass
class TaskConfig:
    task_id: str
    version: int
    description: str
    owner: str
    input_schema: dict[str, Any]
    output_schema: dict[str, Any]
    prompt_text: str
    prompt_id: str
    model_config_id: str
    max_tokens: int
    temperature: float
    input_guardrails: list[GuardrailSpec]
    output_guardrails: list[GuardrailSpec]
    metadata_tags: list[MetadataTagSpec]
    sub_tasks: list[SubTaskSpec]
    task_dir: Path


def _load_json(path: Path) -> dict[str, Any]:
    try:
        with path.open() as f:
            return json.load(f)
    except FileNotFoundError as e:
        raise TaskConfigError(f"Missing file: {path}") from e
    except json.JSONDecodeError as e:
        raise TaskConfigError(f"Invalid JSON in {path}: {e}") from e


def _parse_guardrails(raw: list[Any] | None) -> list[GuardrailSpec]:
    if not raw:
        return []
    parsed = []
    for entry in raw:
        if isinstance(entry, str):
            parsed.append(GuardrailSpec(name=entry))
        elif isinstance(entry, dict):
            if len(entry) != 1:
                raise TaskConfigError(
                    f"Guardrail entry must have exactly one key: {entry}"
                )
            name, params = next(iter(entry.items()))
            if not isinstance(params, dict):
                raise TaskConfigError(
                    f"Guardrail '{name}' params must be a mapping, got {type(params)}"
                )
            parsed.append(GuardrailSpec(name=name, params=params))
        else:
            raise TaskConfigError(f"Unrecognized guardrail entry: {entry}")
    return parsed


def load_task_config(task_dir: Path) -> TaskConfig:
    task_yaml_path = task_dir / "task.yaml"
    if not task_yaml_path.exists():
        raise TaskConfigError(f"No task.yaml in {task_dir}")

    with task_yaml_path.open() as f:
        raw = yaml.safe_load(f)

    required = ("task_id", "version", "prompt", "model")
    for key in required:
        if key not in raw:
            raise TaskConfigError(f"task.yaml missing required key: {key}")

    input_schema = _load_json(task_dir / raw.get("input_schema", "input_schema.json"))
    output_schema = _load_json(task_dir / raw.get("output_schema", "output_schema.json"))

    prompt_source = task_dir / raw["prompt"].get("source_file", "prompt.md")
    if not prompt_source.exists():
        raise TaskConfigError(f"Prompt file missing: {prompt_source}")
    prompt_text = prompt_source.read_text()

    sub_tasks = []
    for st in raw.get("sub_tasks") or []:
        sub_tasks.append(
            SubTaskSpec(
                task_id=st["task_id"],
                cache_key_template=st["cache_key"],
                cache_ttl_seconds=st.get("cache_ttl", 3600),
                inject_as=st["inject_as"],
            )
        )

    metadata_tags = []
    for tag in raw.get("metadata_tags") or []:
        metadata_tags.append(MetadataTagSpec(path=tag["path"], as_name=tag["as"]))

    guardrails_raw = raw.get("guardrails") or {}

    return TaskConfig(
        task_id=raw["task_id"],
        version=int(raw["version"]),
        description=raw.get("description", ""),
        owner=raw.get("owner", ""),
        input_schema=input_schema,
        output_schema=output_schema,
        prompt_text=prompt_text,
        prompt_id=raw["prompt"]["portkey_prompt_id"],
        model_config_id=raw["model"]["config_id"],
        max_tokens=int(raw["model"].get("max_tokens", 2000)),
        temperature=float(raw["model"].get("temperature", 0.2)),
        input_guardrails=_parse_guardrails(guardrails_raw.get("input")),
        output_guardrails=_parse_guardrails(guardrails_raw.get("output")),
        metadata_tags=metadata_tags,
        sub_tasks=sub_tasks,
        task_dir=task_dir,
    )
