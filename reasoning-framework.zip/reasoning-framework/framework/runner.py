"""ReasoningTaskRunner: the orchestrator.

This is the only entry point task callers should use. It:
    1. Loads task config
    2. Validates input schema
    3. Runs input guardrails (may mutate payload, e.g. PII redaction)
    4. Resolves and injects sub-tasks (cached macro calls)
    5. Extracts metadata tags
    6. Calls Portkey with the configured prompt
    7. Parses output (json_only guardrail is implicit if not configured)
    8. Re-hydrates any PII tokens
    9. Validates output schema
    10. Runs output guardrails
    11. Returns a TaskResult with full trace
"""
from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any, Callable

import structlog

from framework.cache import CacheBackend, default_cache, render_cache_key
from framework.config import GuardrailSpec, TaskConfig, load_task_config
from framework.exceptions import (
    GuardrailRejection,
    PortkeyCallError,
    SchemaValidationError,
)
from framework.guardrails import build_guardrail
from framework.logging_setup import get_logger
from framework.metadata import extract_tags
from framework.portkey_client import PortkeyClient
from framework.schema_validator import validate
from framework.types import (
    GuardrailResult,
    GuardrailStage,
    TaskResult,
    TaskStatus,
    TaskTrace,
)

log = get_logger(__name__)

# Type for sub-task resolver: given a sub-task id and the parent input,
# returns the value to inject. Real implementation would itself call the runner.
SubTaskResolver = Callable[[str, dict[str, Any]], Any]


class ReasoningTaskRunner:
    def __init__(
        self,
        task_id: str,
        tasks_root: Path | str = "tasks",
        portkey_client: PortkeyClient | None = None,
        cache: CacheBackend | None = None,
        sub_task_resolver: SubTaskResolver | None = None,
    ):
        self.task_id = task_id
        self.task_dir = Path(tasks_root) / task_id
        self.config: TaskConfig = load_task_config(self.task_dir)
        if self.config.task_id != task_id:
            raise ValueError(
                f"task_id mismatch: folder={task_id} config={self.config.task_id}"
            )
        self.portkey = portkey_client or PortkeyClient()
        self.cache = cache or default_cache()
        self.sub_task_resolver = sub_task_resolver

    def execute(
        self,
        input_data: dict[str, Any],
        request_id: str | None = None,
    ) -> TaskResult:
        request_id = request_id or str(uuid.uuid4())
        ctx = structlog.contextvars.bound_contextvars(
            request_id=request_id,
            task_id=self.task_id,
            task_version=self.config.version,
        )
        with ctx:
            return self._execute(input_data, request_id)

    def _execute(self, input_data: dict[str, Any], request_id: str) -> TaskResult:
        trace = self._new_trace(request_id)

        # 1. Validate input schema (fail fast, before any LLM cost).
        try:
            validate(input_data, self.config.input_schema, "input")
        except SchemaValidationError as e:
            log.error("input_schema_invalid", errors=e.errors)
            return TaskResult(
                status=TaskStatus.SCHEMA_INVALID_INPUT,
                output=None,
                trace=trace,
                error=str(e),
                rejection_reasons=e.errors,
            )

        # 2. Input guardrails.
        input_for_model = input_data
        for spec in self.config.input_guardrails:
            result = self._run_guardrail(
                spec, input_for_model, GuardrailStage.INPUT, input_data
            )
            trace.guardrails.append(result)
            if not result.passed:
                log.warning("input_guardrail_failed", guardrail=spec.name, detail=result.detail)
                return TaskResult(
                    status=TaskStatus.GUARDRAIL_REJECTED,
                    output=None,
                    trace=trace,
                    rejection_reasons=[f"input/{spec.name}: {result.detail}"],
                )
            if result.mutated_payload is not None:
                input_for_model = result.mutated_payload

        # Strip PII mapping (if any) before sending to model.
        pii_mapping = input_for_model.pop("__pii_mapping__", {}) if isinstance(input_for_model, dict) else {}

        # 3. Resolve sub-tasks.
        for sub in self.config.sub_tasks:
            cache_key = render_cache_key(sub.cache_key_template, input_data)
            cached = self.cache.get(f"{sub.task_id}:{cache_key}")
            if cached is None:
                if self.sub_task_resolver is None:
                    log.warning(
                        "subtask_resolver_missing",
                        sub_task=sub.task_id,
                        note="proceeding without sub-task injection",
                    )
                    continue
                cached = self.sub_task_resolver(sub.task_id, input_data)
                self.cache.set(f"{sub.task_id}:{cache_key}", cached, sub.cache_ttl_seconds)
            self._inject_at_path(input_for_model, sub.inject_as, cached)

        # 4. Metadata tags.
        tags = extract_tags(input_data, self.config.metadata_tags)
        tags["request_id"] = request_id
        tags["task_id"] = self.task_id
        tags["task_version"] = str(self.config.version)
        trace.metadata_tags = tags

        # 5. Call Portkey.
        try:
            response = self.portkey.call_prompt(
                prompt_id=self.config.prompt_id,
                variables={"input_json": input_for_model},
                config_id=self.config.model_config_id,
                metadata=tags,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
            )
        except PortkeyCallError as e:
            log.error("portkey_call_failed", error=str(e))
            return TaskResult(
                status=TaskStatus.MODEL_ERROR,
                output=None,
                trace=trace,
                error=str(e),
            )

        trace.model_used = response.model
        trace.portkey_trace_id = response.trace_id
        trace.input_tokens = response.input_tokens
        trace.output_tokens = response.output_tokens
        trace.cost_usd = response.cost_usd
        trace.latency_ms = response.latency_ms

        # 6. Parse output via json_only (implicitly run even if not configured).
        parsed_output = self._parse_output(response.text, trace, input_data)
        if isinstance(parsed_output, TaskResult):
            return parsed_output  # rejection
        output = parsed_output

        # 7. Re-hydrate PII tokens.
        if pii_mapping:
            output = self._rehydrate_pii(output, pii_mapping)

        # 8. Validate output schema.
        try:
            validate(output, self.config.output_schema, "output")
        except SchemaValidationError as e:
            log.error("output_schema_invalid", errors=e.errors)
            return TaskResult(
                status=TaskStatus.SCHEMA_INVALID_OUTPUT,
                output=output,
                trace=trace,
                error=str(e),
                rejection_reasons=e.errors,
            )

        # 9. Output guardrails.
        reasons: list[str] = []
        for spec in self.config.output_guardrails:
            if spec.name == "json_only":
                continue  # already handled
            result = self._run_guardrail(
                spec, output, GuardrailStage.OUTPUT, input_data
            )
            trace.guardrails.append(result)
            if not result.passed:
                reasons.append(f"output/{spec.name}: {result.detail}")
            elif result.mutated_payload is not None:
                output = result.mutated_payload

        if reasons:
            log.warning("output_guardrails_failed", reasons=reasons)
            return TaskResult(
                status=TaskStatus.GUARDRAIL_REJECTED,
                output=output,  # surface for debugging; caller must not deliver
                trace=trace,
                rejection_reasons=reasons,
            )

        log.info(
            "task_success",
            latency_ms=trace.latency_ms,
            input_tokens=trace.input_tokens,
            output_tokens=trace.output_tokens,
        )
        return TaskResult(status=TaskStatus.SUCCESS, output=output, trace=trace)

    # ----- helpers -----

    def _new_trace(self, request_id: str) -> TaskTrace:
        return TaskTrace(
            request_id=request_id,
            task_id=self.task_id,
            task_version=self.config.version,
            prompt_id=self.config.prompt_id,
            prompt_version=None,
            model_config_id=self.config.model_config_id,
            model_used=None,
            portkey_trace_id=None,
            latency_ms=None,
            input_tokens=None,
            output_tokens=None,
            cost_usd=None,
            metadata_tags={},
            guardrails=[],
        )

    def _run_guardrail(
        self,
        spec: GuardrailSpec,
        payload: Any,
        stage: GuardrailStage,
        input_payload: dict[str, Any],
    ) -> GuardrailResult:
        params = dict(spec.params)
        # Inject the right schema for schema_validation, depending on stage.
        if spec.name == "schema_validation":
            if stage == GuardrailStage.INPUT:
                params["_schema"] = self.config.input_schema
            else:
                params["_schema"] = self.config.output_schema
        guardrail = build_guardrail(spec.name, params)
        if stage not in guardrail.supports_stages:
            return GuardrailResult(
                name=spec.name,
                stage=stage,
                passed=False,
                detail=f"{spec.name} does not support stage {stage.value}",
            )
        try:
            return guardrail.check(payload, stage=stage, input_payload=input_payload)
        except Exception as e:  # never let a guardrail bug crash the runner
            log.exception("guardrail_exception", guardrail=spec.name)
            return GuardrailResult(
                name=spec.name,
                stage=stage,
                passed=False,
                detail=f"guardrail raised {type(e).__name__}: {e}",
            )

    def _parse_output(
        self,
        text: str,
        trace: TaskTrace,
        input_payload: dict[str, Any],
    ) -> dict[str, Any] | TaskResult:
        from framework.guardrails.json_only import JsonOnlyGuardrail
        result = JsonOnlyGuardrail({}).check(
            text, stage=GuardrailStage.OUTPUT, input_payload=input_payload
        )
        trace.guardrails.append(result)
        if not result.passed:
            return TaskResult(
                status=TaskStatus.SCHEMA_INVALID_OUTPUT,
                output=None,
                trace=trace,
                error=result.detail,
                rejection_reasons=[result.detail],
            )
        return result.mutated_payload  # type: ignore[return-value]

    @staticmethod
    def _inject_at_path(payload: dict[str, Any], path: str, value: Any) -> None:
        # path like "input.book_drivers.plain_language" — strip leading "input."
        parts = path.split(".")
        if parts[0] == "input":
            parts = parts[1:]
        cur: Any = payload
        for part in parts[:-1]:
            if not isinstance(cur, dict):
                return
            cur = cur.setdefault(part, {})
        if isinstance(cur, dict):
            cur[parts[-1]] = value

    @staticmethod
    def _rehydrate_pii(payload: Any, mapping: dict[str, str]) -> Any:
        if not mapping:
            return payload
        if isinstance(payload, str):
            for tok, real in mapping.items():
                payload = payload.replace(tok, real)
            return payload
        if isinstance(payload, dict):
            return {k: ReasoningTaskRunner._rehydrate_pii(v, mapping) for k, v in payload.items()}
        if isinstance(payload, list):
            return [ReasoningTaskRunner._rehydrate_pii(v, mapping) for v in payload]
        return payload
