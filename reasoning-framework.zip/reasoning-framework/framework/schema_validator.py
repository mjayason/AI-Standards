"""Thin wrapper around jsonschema. Centralizes error formatting."""
from __future__ import annotations

from typing import Any

from jsonschema import Draft202012Validator

from framework.exceptions import SchemaValidationError


def validate(payload: Any, schema: dict[str, Any], label: str) -> None:
    """Raise SchemaValidationError with all errors collected, not just the first."""
    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(payload), key=lambda e: list(e.absolute_path))
    if not errors:
        return
    formatted = []
    for err in errors:
        path = ".".join(str(p) for p in err.absolute_path) or "<root>"
        formatted.append(f"{path}: {err.message}")
    raise SchemaValidationError(
        f"{label} failed JSON Schema validation ({len(errors)} errors)",
        formatted,
    )
