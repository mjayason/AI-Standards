"""Portkey client wrapper.

Centralizes:
    - Portkey SDK invocation
    - Retry policy (handled by Portkey config, but we retry on hard failures)
    - Metadata attachment
    - Trace ID extraction for audit logging
    - A 'mock' mode for local testing without API credentials

The runner never calls portkey-ai directly; it goes through this wrapper.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from typing import Any

from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from framework.exceptions import PortkeyCallError
from framework.logging_setup import get_logger

log = get_logger(__name__)


@dataclass
class PortkeyResponse:
    text: str
    model: str | None
    trace_id: str | None
    input_tokens: int | None
    output_tokens: int | None
    cost_usd: float | None
    latency_ms: int


class PortkeyClient:
    def __init__(
        self,
        api_key: str | None = None,
        mock: bool = False,
        mock_response_factory: Any = None,
    ):
        self.api_key = api_key or os.getenv("PORTKEY_API_KEY")
        self.mock = mock or os.getenv("PORTKEY_MOCK") == "1"
        self._mock_response_factory = mock_response_factory
        self._real_client = None
        if not self.mock:
            if not self.api_key:
                raise PortkeyCallError(
                    "PORTKEY_API_KEY not set and mock mode not enabled"
                )
            try:
                from portkey_ai import Portkey  # type: ignore
            except ImportError as e:
                raise PortkeyCallError(
                    "portkey-ai package not installed"
                ) from e
            self._real_client = Portkey(api_key=self.api_key)

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type(PortkeyCallError),
        reraise=True,
    )
    def call_prompt(
        self,
        *,
        prompt_id: str,
        variables: dict[str, Any],
        config_id: str,
        metadata: dict[str, str],
        max_tokens: int,
        temperature: float,
    ) -> PortkeyResponse:
        if self.mock:
            return self._mock_call(prompt_id, variables, metadata)

        start = time.perf_counter()
        try:
            # Portkey's prompts.completions.create supports prompt_id + variables.
            response = self._real_client.prompts.completions.create(  # type: ignore[union-attr]
                prompt_id=prompt_id,
                variables=variables,
                config=config_id,
                metadata=metadata,
                max_tokens=max_tokens,
                temperature=temperature,
            )
        except Exception as e:
            log.error(
                "portkey_call_failed",
                prompt_id=prompt_id,
                error=str(e),
            )
            raise PortkeyCallError(f"Portkey call failed: {e}") from e

        elapsed_ms = int((time.perf_counter() - start) * 1000)
        text = self._extract_text(response)
        usage = getattr(response, "usage", None) or {}
        if not isinstance(usage, dict):
            usage = getattr(usage, "__dict__", {})

        return PortkeyResponse(
            text=text,
            model=getattr(response, "model", None),
            trace_id=self._extract_trace_id(response),
            input_tokens=usage.get("prompt_tokens") or usage.get("input_tokens"),
            output_tokens=usage.get("completion_tokens") or usage.get("output_tokens"),
            cost_usd=getattr(response, "cost", None),
            latency_ms=elapsed_ms,
        )

    @staticmethod
    def _extract_text(response: Any) -> str:
        # Portkey responses follow OpenAI-compatible shape.
        try:
            choices = getattr(response, "choices", None) or response.get("choices", [])
            if not choices:
                return ""
            first = choices[0]
            msg = getattr(first, "message", None) or first.get("message", {})
            content = getattr(msg, "content", None) if msg else None
            if content is None and isinstance(msg, dict):
                content = msg.get("content")
            if isinstance(content, list):
                # Anthropic-style content blocks
                return "".join(
                    block.get("text", "") if isinstance(block, dict) else ""
                    for block in content
                )
            return content or ""
        except Exception:
            return ""

    @staticmethod
    def _extract_trace_id(response: Any) -> str | None:
        # Portkey returns trace_id in response headers or top-level field.
        return (
            getattr(response, "trace_id", None)
            or getattr(response, "id", None)
        )

    def _mock_call(
        self,
        prompt_id: str,
        variables: dict[str, Any],
        metadata: dict[str, str],
    ) -> PortkeyResponse:
        log.info("portkey_mock_call", prompt_id=prompt_id, metadata=metadata)
        if self._mock_response_factory is not None:
            text = self._mock_response_factory(prompt_id, variables, metadata)
        else:
            text = json.dumps({"_mock": True, "prompt_id": prompt_id})
        return PortkeyResponse(
            text=text,
            model="mock-model",
            trace_id="mock-trace-id",
            input_tokens=100,
            output_tokens=200,
            cost_usd=0.0,
            latency_ms=50,
        )
