"""Sub-task cache. In production, swap _MemoryBackend for Redis.

Used for things like macro book-driver translations that are identical across
thousands of customer briefs. The cache key is rendered from a template against
the input payload (e.g. "{state}:{lob}:{cycle}").
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from threading import Lock
from typing import Any, Protocol

from framework.metadata import get_by_path


class CacheBackend(Protocol):
    def get(self, key: str) -> Any | None: ...
    def set(self, key: str, value: Any, ttl_seconds: int) -> None: ...


@dataclass
class _Entry:
    value: Any
    expires_at: float


class MemoryBackend:
    def __init__(self) -> None:
        self._store: dict[str, _Entry] = {}
        self._lock = Lock()

    def get(self, key: str) -> Any | None:
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            if entry.expires_at < time.time():
                del self._store[key]
                return None
            return entry.value

    def set(self, key: str, value: Any, ttl_seconds: int) -> None:
        with self._lock:
            self._store[key] = _Entry(value=value, expires_at=time.time() + ttl_seconds)


def render_cache_key(template: str, input_payload: dict[str, Any]) -> str:
    """Render '{state}:{lob}:{cycle}' against input via dotted-path lookup.

    By convention sub-task cache keys reference top-level fields under either
    'compliance' or 'book_drivers' in the input. We try a small set of common
    parent paths so task authors don't need to spell out 'compliance.state'.
    """
    wrapped = {"input": input_payload}
    import re

    def resolve(match: re.Match) -> str:
        name = match.group(1)
        for parent in ("input.compliance", "input.book_drivers", "input.policy", "input"):
            value = get_by_path(wrapped, f"{parent}.{name}")
            if value is not None:
                return str(value)
        return f"<missing:{name}>"

    return re.sub(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}", resolve, template)


_default_backend = MemoryBackend()


def default_cache() -> CacheBackend:
    return _default_backend
