"""Shared types. Kept minimal and dependency-light."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class TaskStatus(str, Enum):
    SUCCESS = "success"
    SCHEMA_INVALID_INPUT = "schema_invalid_input"
    SCHEMA_INVALID_OUTPUT = "schema_invalid_output"
    GUARDRAIL_REJECTED = "guardrail_rejected"
    MODEL_ERROR = "model_error"
    CONFIG_ERROR = "config_error"


class GuardrailStage(str, Enum):
    INPUT = "input"
    OUTPUT = "output"


@dataclass
class GuardrailResult:
    name: str
    stage: GuardrailStage
    passed: bool
    detail: str = ""
    # If a guardrail mutates the payload (e.g. PII redaction), it returns the
    # new payload here. None means no mutation.
    mutated_payload: Any = None


@dataclass
class TaskTrace:
    """Everything needed to audit a single task execution."""
    request_id: str
    task_id: str
    task_version: int
    prompt_id: str
    prompt_version: int | None
    model_config_id: str
    model_used: str | None
    portkey_trace_id: str | None
    latency_ms: int | None
    input_tokens: int | None
    output_tokens: int | None
    cost_usd: float | None
    metadata_tags: dict[str, Any]
    guardrails: list[GuardrailResult]


@dataclass
class TaskResult:
    status: TaskStatus
    output: dict[str, Any] | None
    trace: TaskTrace
    error: str | None = None
    rejection_reasons: list[str] = field(default_factory=list)
