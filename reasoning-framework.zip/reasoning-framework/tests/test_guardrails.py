"""Guardrail unit tests. Run with: pytest tests/"""
from __future__ import annotations

import pytest

from framework.guardrails import build_guardrail
from framework.types import GuardrailStage


def test_json_only_passes_clean_json():
    g = build_guardrail("json_only", {})
    r = g.check('{"a": 1}', stage=GuardrailStage.OUTPUT, input_payload={})
    assert r.passed
    assert r.mutated_payload == {"a": 1}


def test_json_only_strips_code_fences():
    g = build_guardrail("json_only", {})
    r = g.check('```json\n{"a": 1}\n```', stage=GuardrailStage.OUTPUT, input_payload={})
    assert r.passed
    assert r.mutated_payload == {"a": 1}


def test_json_only_rejects_garbage():
    g = build_guardrail("json_only", {})
    r = g.check("not json at all", stage=GuardrailStage.OUTPUT, input_payload={})
    assert not r.passed


def test_word_count_under_limit():
    g = build_guardrail("word_count", {"max": 10})
    r = g.check({"text": "one two three"}, stage=GuardrailStage.OUTPUT, input_payload={})
    assert r.passed


def test_word_count_over_limit():
    g = build_guardrail("word_count", {"max": 3})
    r = g.check({"text": "one two three four five"}, stage=GuardrailStage.OUTPUT, input_payload={})
    assert not r.passed


def test_prohibited_phrases_finds_match():
    g = build_guardrail("prohibited_phrases", {"static": ["unfortunately"]})
    r = g.check(
        {"response": "Unfortunately we can't help."},
        stage=GuardrailStage.OUTPUT,
        input_payload={},
    )
    assert not r.passed
    assert "unfortunately" in r.detail.lower()


def test_prohibited_phrases_clean():
    g = build_guardrail("prohibited_phrases", {"static": ["guaranteed"]})
    r = g.check(
        {"response": "Here are your options."},
        stage=GuardrailStage.OUTPUT,
        input_payload={},
    )
    assert r.passed


def test_required_phrases_present():
    g = build_guardrail("required_phrases_present", {
        "source": "input.compliance.required_disclosures",
    })
    input_p = {"compliance": {"required_disclosures": ["Disclosure A"]}}
    r = g.check(
        {"disclosures": ["Disclosure A"]},
        stage=GuardrailStage.OUTPUT,
        input_payload=input_p,
    )
    assert r.passed


def test_required_phrases_missing():
    g = build_guardrail("required_phrases_present", {
        "source": "input.compliance.required_disclosures",
    })
    input_p = {"compliance": {"required_disclosures": ["Disclosure A"]}}
    r = g.check(
        {"disclosures": ["Something else"]},
        stage=GuardrailStage.OUTPUT,
        input_payload=input_p,
    )
    assert not r.passed


def test_numeric_match_passes_when_all_numbers_in_input():
    g = build_guardrail("numeric_values_match_input", {})
    input_p = {"policy": {"current": 1842.00, "new": 2156.00, "change": 314.00}}
    r = g.check(
        {"snapshot": {"current": 1842.00, "new": 2156.00, "delta": "+$314"}},
        stage=GuardrailStage.OUTPUT,
        input_payload=input_p,
    )
    assert r.passed


def test_numeric_match_catches_invented_number():
    g = build_guardrail("numeric_values_match_input", {})
    input_p = {"policy": {"current": 1842.00, "new": 2156.00}}
    r = g.check(
        {"snapshot": {"savings": "$847"}},  # 847 not in input
        stage=GuardrailStage.OUTPUT,
        input_payload=input_p,
    )
    assert not r.passed
    assert "847" in r.detail


def test_numeric_match_allows_derived_percent():
    g = build_guardrail("numeric_values_match_input", {"allow_derived": True})
    input_p = {"policy": {"current": 1842.00, "new": 2156.00}}
    # (2156-1842)/1842 * 100 = 17.05
    r = g.check(
        {"snapshot": {"display": "+17.0%"}},
        stage=GuardrailStage.OUTPUT,
        input_payload=input_p,
    )
    assert r.passed


def test_referenced_ids_exist_pass():
    g = build_guardrail("referenced_ids_exist", {
        "references": [{
            "output_path": "options_to_offer",
            "input_path": "options_catalog",
            "id_field": "option_id",
        }],
    })
    input_p = {"options_catalog": [{"option_id": "OPT_A"}, {"option_id": "OPT_B"}]}
    r = g.check(
        {"options_to_offer": [{"option_id": "OPT_A"}]},
        stage=GuardrailStage.OUTPUT,
        input_payload=input_p,
    )
    assert r.passed


def test_referenced_ids_exist_fail():
    g = build_guardrail("referenced_ids_exist", {
        "references": [{
            "output_path": "options_to_offer",
            "input_path": "options_catalog",
            "id_field": "option_id",
        }],
    })
    input_p = {"options_catalog": [{"option_id": "OPT_A"}]}
    r = g.check(
        {"options_to_offer": [{"option_id": "OPT_HALLUCINATED"}]},
        stage=GuardrailStage.OUTPUT,
        input_payload=input_p,
    )
    assert not r.passed


def test_pii_redaction_replaces_fields():
    g = build_guardrail("pii_redaction", {"fields": ["customer.full_name", "customer.email"]})
    payload = {"customer": {"full_name": "Margaret Holloway", "email": "[email protected]"}}
    r = g.check(payload, stage=GuardrailStage.INPUT, input_payload=payload)
    assert r.passed
    new = r.mutated_payload
    assert new["customer"]["full_name"].startswith("__PII_")
    assert new["customer"]["email"].startswith("__PII_")
    assert "__pii_mapping__" in new
