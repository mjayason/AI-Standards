"""End-to-end runner tests using mock Portkey responses."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from framework.portkey_client import PortkeyClient
from framework.runner import ReasoningTaskRunner
from framework.types import TaskStatus


REPO_ROOT = Path(__file__).resolve().parent.parent


def _load(path: str) -> dict:
    with open(REPO_ROOT / path) as f:
        return json.load(f)


def _precall_mock_factory(prompt_id, variables, metadata):
    inp = variables["input_json"]
    return json.dumps({
        "snapshot": {
            "customer_name_ref": "the customer",
            "tenure_years": inp["customer"]["tenure_years"],
            "policy_summary": "auto policy, 12-month term",
            "current_premium": inp["policy"]["current_premium"],
            "new_premium": inp["policy"]["new_premium"],
            "change_display": f"+${inp['policy']['change_amount']:.0f}",
            "effective_date": inp["policy"]["effective_date"],
        },
        "read_on_customer": {
            "segment": "loyal_low_claim",
            "segment_evidence": "Long tenure with no claims.",
            "emotional_starting_point": "Likely feels loyalty is being penalized.",
        },
        "why_premium_changed": [
            {"driver": "Statewide rates increased due to repair and medical costs.", "approximate_dollar_impact": 178.00},
        ],
        "options_to_offer": [
            {"rank": 1, "option_id": "OPT_COVERAGE_REVIEW", "label": "Coverage review", "dollar_impact": 0.00, "trade_off": "May identify reducible coverages.", "why_this_customer": "Long tenure means coverage may be out of date."},
        ],
        "likely_objections": [
            {"objection": "I've been with you 18 years.", "emotion_underneath": "Feels unrewarded.", "response": "Acknowledge the tenure explicitly and explain the cost drivers.", "pivot_to": "tenure_acknowledgment"},
        ],
        "watch_outs": ["High lifetime value customer."],
        "do_not_say": ["There's nothing I can do."],
        "authority_reminder": {
            "max_retention_credit": 75.00,
            "can_offer_without_escalation": ["loyalty credit"],
            "must_escalate_if": ["request above $75"],
        },
        "compliance_flags": {
            "required_disclosures": ["This rate change was approved by the Texas Department of Insurance."],
            "state_specific_notes": [],
        },
        "retention_risk": {
            "score_band": "medium",
            "primary_lever": "Acknowledge tenure and offer telematics.",
        },
    })


def test_precall_brief_runs_end_to_end():
    client = PortkeyClient(mock=True, mock_response_factory=_precall_mock_factory)
    runner = ReasoningTaskRunner(
        task_id="precall_brief",
        tasks_root=str(REPO_ROOT / "tasks"),
        portkey_client=client,
    )
    input_data = _load("tasks/precall_brief/tests/fixtures/loyal_customer.json")
    result = runner.execute(input_data)
    assert result.status == TaskStatus.SUCCESS, (
        f"Expected SUCCESS, got {result.status.value}: {result.rejection_reasons}"
    )
    assert result.output is not None
    assert result.output["read_on_customer"]["segment"] == "loyal_low_claim"
    # Trace must be populated
    assert result.trace.metadata_tags.get("lob") == "auto"
    assert result.trace.metadata_tags.get("state") == "TX"


def test_precall_brief_rejects_hallucinated_dollar():
    def bad_factory(prompt_id, variables, metadata):
        good = json.loads(_precall_mock_factory(prompt_id, variables, metadata))
        # Inject a fake $9,999 figure that's not in input
        good["why_premium_changed"][0]["approximate_dollar_impact"] = 9999.00
        return json.dumps(good)

    client = PortkeyClient(mock=True, mock_response_factory=bad_factory)
    runner = ReasoningTaskRunner(
        task_id="precall_brief",
        tasks_root=str(REPO_ROOT / "tasks"),
        portkey_client=client,
    )
    input_data = _load("tasks/precall_brief/tests/fixtures/loyal_customer.json")
    result = runner.execute(input_data)
    assert result.status == TaskStatus.GUARDRAIL_REJECTED
    assert any("numeric_values_match_input" in r for r in result.rejection_reasons)


def test_precall_brief_rejects_hallucinated_option_id():
    def bad_factory(prompt_id, variables, metadata):
        good = json.loads(_precall_mock_factory(prompt_id, variables, metadata))
        good["options_to_offer"][0]["option_id"] = "OPT_DOES_NOT_EXIST"
        return json.dumps(good)

    client = PortkeyClient(mock=True, mock_response_factory=bad_factory)
    runner = ReasoningTaskRunner(
        task_id="precall_brief",
        tasks_root=str(REPO_ROOT / "tasks"),
        portkey_client=client,
    )
    input_data = _load("tasks/precall_brief/tests/fixtures/loyal_customer.json")
    result = runner.execute(input_data)
    assert result.status == TaskStatus.GUARDRAIL_REJECTED
    assert any("referenced_ids_exist" in r for r in result.rejection_reasons)


def test_precall_brief_rejects_prohibited_phrase():
    def bad_factory(prompt_id, variables, metadata):
        good = json.loads(_precall_mock_factory(prompt_id, variables, metadata))
        good["likely_objections"][0]["response"] = "Unfortunately there is nothing I can do."
        return json.dumps(good)

    client = PortkeyClient(mock=True, mock_response_factory=bad_factory)
    runner = ReasoningTaskRunner(
        task_id="precall_brief",
        tasks_root=str(REPO_ROOT / "tasks"),
        portkey_client=client,
    )
    input_data = _load("tasks/precall_brief/tests/fixtures/loyal_customer.json")
    result = runner.execute(input_data)
    assert result.status == TaskStatus.GUARDRAIL_REJECTED
    assert any("prohibited_phrases" in r for r in result.rejection_reasons)


def test_input_schema_invalid_rejected_before_llm_call():
    client = PortkeyClient(mock=True, mock_response_factory=_precall_mock_factory)
    runner = ReasoningTaskRunner(
        task_id="precall_brief",
        tasks_root=str(REPO_ROOT / "tasks"),
        portkey_client=client,
    )
    bad_input = {"policy": {}}  # missing required fields everywhere
    result = runner.execute(bad_input)
    assert result.status == TaskStatus.SCHEMA_INVALID_INPUT
    # Critical: no Portkey call should have been made — model_used stays None
    assert result.trace.model_used is None
