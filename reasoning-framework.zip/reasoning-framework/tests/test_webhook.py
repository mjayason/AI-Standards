"""Webhook integration tests.

Uses FastAPI's TestClient to simulate Portkey calling the webhook with the
same request/response shapes it would in production.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from webhook.server import app

REPO_ROOT = Path(__file__).resolve().parent.parent
client = TestClient(app)


def _load_fixture(path: str) -> dict:
    with open(REPO_ROOT / path) as f:
        return json.load(f)


def _good_output(input_data: dict) -> dict:
    """A minimally valid precall_brief output that satisfies all guardrails."""
    return {
        "snapshot": {
            "customer_name_ref": "the customer",
            "tenure_years": input_data["customer"]["tenure_years"],
            "policy_summary": "auto policy",
            "current_premium": input_data["policy"]["current_premium"],
            "new_premium": input_data["policy"]["new_premium"],
            "change_display": f"+${input_data['policy']['change_amount']:.0f}",
            "effective_date": input_data["policy"]["effective_date"],
        },
        "read_on_customer": {
            "segment": "loyal_low_claim",
            "segment_evidence": "Long tenure, no claims.",
            "emotional_starting_point": "Likely to feel loyalty is being penalized.",
        },
        "why_premium_changed": [
            {"driver": "Statewide rates rose due to costs.", "approximate_dollar_impact": 178.00},
        ],
        "options_to_offer": [
            {"rank": 1, "option_id": "OPT_COVERAGE_REVIEW", "label": "Coverage review", "dollar_impact": 0.00, "trade_off": "May identify reducible coverages.", "why_this_customer": "Long tenure means coverage may be out of date."},
        ],
        "likely_objections": [
            {"objection": "I've been with you 18 years.", "emotion_underneath": "Unrewarded.", "response": "Acknowledge tenure and explain drivers.", "pivot_to": "tenure_acknowledgment"},
        ],
        "watch_outs": ["High lifetime value customer."],
        "do_not_say": ["There's nothing I can do."],
        "authority_reminder": {
            "max_retention_credit": 75.00,
            "can_offer_without_escalation": ["loyalty credit"],
            "must_escalate_if": ["above $75"],
        },
        "compliance_flags": {
            "required_disclosures": ["This rate change was approved by the Texas Department of Insurance."],
            "state_specific_notes": [],
        },
        "retention_risk": {
            "score_band": "medium",
            "primary_lever": "Acknowledge tenure.",
        },
    }


def _portkey_payload(input_data: dict, output: dict) -> dict:
    """Shape mimicking what Portkey forwards to the webhook."""
    return {
        "request": {
            "prompt_id": "precall-brief",
            "variables": {"input_json": input_data},
        },
        "response": {
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": json.dumps(output),
                },
            }],
        },
        "metadata": {
            "task_id": "precall_brief",
            "task_version": "7",
        },
    }


def test_healthz():
    r = client.get("/healthz")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_readyz_lists_tasks():
    r = client.get("/readyz")
    assert r.status_code == 200
    assert "precall_brief" in r.json()["tasks_available"]


def test_clean_output_passes():
    input_data = _load_fixture("tasks/precall_brief/tests/fixtures/loyal_customer.json")
    output = _good_output(input_data)
    payload = _portkey_payload(input_data, output)

    r = client.post(
        "/guardrails/check",
        json=payload,
        headers={"x-task-id": "precall_brief", "x-task-version": "7", "x-mode": "enforce"},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["verdict"] is True, body
    assert body["reasons"] == []
    # All expected gateway-side checks should have run
    check_names = {c["name"] for c in body["checks"]}
    assert "numeric_values_match_input" in check_names
    assert "referenced_ids_exist" in check_names
    assert "prohibited_phrases" in check_names


def test_hallucinated_dollar_rejected():
    input_data = _load_fixture("tasks/precall_brief/tests/fixtures/loyal_customer.json")
    output = _good_output(input_data)
    output["why_premium_changed"][0]["approximate_dollar_impact"] = 9999.00
    payload = _portkey_payload(input_data, output)

    r = client.post(
        "/guardrails/check",
        json=payload,
        headers={"x-task-id": "precall_brief", "x-task-version": "7", "x-mode": "enforce"},
    )
    body = r.json()
    assert body["verdict"] is False
    assert any("numeric_values_match_input" in reason for reason in body["reasons"])


def test_hallucinated_option_id_rejected():
    input_data = _load_fixture("tasks/precall_brief/tests/fixtures/loyal_customer.json")
    output = _good_output(input_data)
    output["options_to_offer"][0]["option_id"] = "OPT_HALLUCINATED"
    payload = _portkey_payload(input_data, output)

    r = client.post(
        "/guardrails/check",
        json=payload,
        headers={"x-task-id": "precall_brief", "x-task-version": "7"},
    )
    body = r.json()
    assert body["verdict"] is False
    assert any("referenced_ids_exist" in reason for reason in body["reasons"])


def test_log_only_mode_does_not_block():
    """In shadow mode, the webhook records violations but returns verdict=True."""
    input_data = _load_fixture("tasks/precall_brief/tests/fixtures/loyal_customer.json")
    output = _good_output(input_data)
    output["why_premium_changed"][0]["approximate_dollar_impact"] = 9999.00
    payload = _portkey_payload(input_data, output)

    r = client.post(
        "/guardrails/check",
        json=payload,
        headers={"x-task-id": "precall_brief", "x-mode": "log_only"},
    )
    body = r.json()
    # Verdict True because mode is log_only, but reasons populated so we can see it.
    assert body["verdict"] is True
    assert len(body["reasons"]) > 0
    assert body["mode"] == "log_only"


def test_unknown_task_fails_closed_in_enforce_mode():
    input_data = _load_fixture("tasks/precall_brief/tests/fixtures/loyal_customer.json")
    payload = _portkey_payload(input_data, _good_output(input_data))
    r = client.post(
        "/guardrails/check",
        json=payload,
        headers={"x-task-id": "does_not_exist", "x-mode": "enforce"},
    )
    assert r.status_code == 404


def test_unknown_task_fails_open_in_log_only_mode():
    input_data = _load_fixture("tasks/precall_brief/tests/fixtures/loyal_customer.json")
    payload = _portkey_payload(input_data, _good_output(input_data))
    r = client.post(
        "/guardrails/check",
        json=payload,
        headers={"x-task-id": "does_not_exist", "x-mode": "log_only"},
    )
    # Log-only mode should not block on missing task.
    assert r.status_code == 200
    assert r.json()["verdict"] is True
